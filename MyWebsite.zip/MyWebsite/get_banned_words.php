<?php
session_start();
include 'db_connect.php';

if ($_SESSION['user_type'] !== 'child') {
    echo json_encode([]);
    exit();
}

$child_id = $_SESSION['user_id'];
$parentQuery = $conn->prepare("SELECT parent_id FROM user_form WHERE id = ?");
$parentQuery->execute([$child_id]);
$parent_id = $parentQuery->fetchColumn();

if ($parent_id) {
    $query = $conn->prepare("SELECT word FROM banned_words WHERE parent_id = ?");
    $query->execute([$parent_id]);
    $bannedWords = $query->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode($bannedWords);
} else {
    echo json_encode([]);
}
?>
