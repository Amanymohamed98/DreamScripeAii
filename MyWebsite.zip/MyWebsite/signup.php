<?php
@include 'db.php';

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $user_type = $_POST['user_type'];

    // تأكد من أن الحقول غير فارغة
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "All fields are required!";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // تأكد من أن البريد الإلكتروني غير موجود مسبقًا
        $check_email = "SELECT * FROM user_form WHERE email = ?";
        $stmt = mysqli_prepare($conn, $check_email);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $error = "User already exists!";
        } else {
            // تشفير كلمة المرور
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // إدخال المستخدم الجديد
            $insert_user = "INSERT INTO user_form (name, email, password, user_type) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $insert_user);
            mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $hashed_password, $user_type);
            
            if (mysqli_stmt_execute($stmt)) {
                header("Location: login.php");
                exit();
            } else {
                $error = "Something went wrong. Please try again!";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dream Scribe AI - Sign Up</title>
  <style>
    body {
      font-family: "Arial", sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f8f8f8;
      opacity: 1;
      transition: opacity 1s ease-in;
    }

    .navbar {
      background-color: #003a53;
      color: white;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .navbar a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
      font-size: 16px;
      transition: color 0.3s;
    }

    .navbar a:hover {
      text-decoration: underline;
      color: #ffcc00;
    }

    .signup-section {
      max-width: 500px;
      margin: 50px auto;
      padding: 30px;
      background: url('download.jfif') no-repeat center center/cover;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      text-align: center;
      opacity: 1;
      transform: translateY(20px);
      transition: opacity 1s ease-out, transform 1s ease-out;
    }

    .signup-section h1 {
      font-size: 28px;
      color: white;
      margin-bottom: 10px;
    }

    .signup-section form {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      background: rgba(255, 255, 255, 0.8);
      padding: 20px;
      border-radius: 10px;
    }

    .signup-section label {
      font-size: 16px;
      margin-bottom: 5px;
      color: #333;
      font-weight: bold;
      align-self: flex-start;
    }

    .signup-section input {
      font-size: 16px;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      width: 100%;
    }

    .signup-section button {
      background-color: #003a53;
      color: white;
      padding: 12px;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      width: 100%;
      margin-top: 10px;
      transition: background-color 0.3s, color 0.3s;
    }

    .signup-section button:hover {
      background-color: #ffcc00;
      color: #003a53;
    }

    .login-link {
      margin-top: 20px;
      text-align: center;
    }

    .login-link a {
      color: #003a53;
      text-decoration: none;
    }

    .login-link a:hover {
      text-decoration: underline;
      color: #ffcc00;
    }

    .password-conditions {
      margin-top: 10px;
      font-size: 14px;
      color: #003a53;
      text-align: left;
      width: 100%;
    }

    .password-conditions li {
      list-style-type: none;
      margin-bottom: 5px;
    }

    .password-conditions .valid {
      color: #28a745;
    }

    .password-conditions .invalid {
      color: #dc3545;
    }

    .password-suggestion {
      margin-top: 10px;
      font-size: 14px;
      color: #003a53;
      font-style: italic;
    }
  </style>
</head>
<body>
  <div class="navbar">
    <h2>Dream Scribe AI</h2>
    <div>
      <a href="index.html">Home</a>
      <a href="about.html">About Us</a>
      <a href="login.php">Log In</a>
    </div>
  </div>

    <div class="signup-section" id="signup">
    <h1>SIGN UP</h1>
    <form id="signup-form" action="signup.php" method="POST">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Your Full Name" required>

        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" placeholder="E-mail" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Password" required>

        <label for="confirm_password">Confirm Password</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>

        <!-- اختيار نوع المستخدم -->
        <label for="user_type">Sign Up As</label>
        <select id="user_type" name="user_type" required>
            <option value="Parent">Parent</option>
            <option value="Child">Child</option>
        </select>

        <div class="login-link">
            Already have an account? <a href="login.php">LOG IN</a>
        </div>

        <button type="submit" name="submit">CREATE</button> 
    </form>
</div>

  </div>
</body>
</html>
