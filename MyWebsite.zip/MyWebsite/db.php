<?php
$servername = "localhost";
$username = "root";  // استخدم اسم المستخدم الصحيح
$password = "";      // ضع كلمة المرور الصحيحة إذا كانت موجودة
$dbname = "user_database";  // استبدل باسم قاعدة البيانات الفعلي

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
