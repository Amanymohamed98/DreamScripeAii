<?php
session_start();
include 'db.php'; // الاتصال بقاعدة البيانات

// التحقق مما إذا كان المستخدم Parent
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "parent") {
    echo "<script>alert('Access Denied! Only parents can manage banned words.'); window.location.href='write_story.php';</script>";
    exit();
}

$parent_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $word = trim($_POST['word']);

    // التحقق من العدد الحالي للكلمات المحظورة
    $countQuery = $conn->prepare("SELECT COUNT(*) FROM banned_words WHERE parent_id = ?");
    $countQuery->bind_param("i", $parent_id);  // ✅ تصحيح الخطأ هنا
    $countQuery->execute();
    $countQuery->bind_result($count);
    $countQuery->fetch();
    $countQuery->close();

    if ($count >= 25) {
        $message = "You can only add up to 25 banned words!";
    } else {
        $stmt = $conn->prepare("INSERT INTO banned_words (parent_id, word) VALUES (?, ?)");
        $stmt->bind_param("is", $parent_id, $word);  // ✅ تصحيح الخطأ هنا
        $stmt->execute();
        $stmt->close();
        $message = "Word added successfully!";
    }
}

// جلب الكلمات الحالية
$query = $conn->prepare("SELECT word FROM banned_words WHERE parent_id = ?");
$query->bind_param("i", $parent_id);  // ✅ تصحيح الخطأ هنا
$query->execute();
$result = $query->get_result();
$bannedWords = $result->fetch_all(MYSQLI_ASSOC);
$query->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Banned Words</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }

        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 50%;
            margin: auto;
        }

        h2, h3 {
            color: #003a53;
        }

        form {
            margin-top: 20px;
        }

        input[type="text"] {
            padding: 10px;
            width: 60%;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #003a53;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
        }

        button:hover {
            background-color: #007a99;
        }

        p {
            font-size: 16px;
            color: green;
            margin-top: 10px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        ul li {
            background: #e0f7fa;
            padding: 10px;
            margin: 5px auto;
            width: 60%;
            border-radius: 5px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Manage Banned Words</h2>
        <form method="post">
            <input type="text" name="word" placeholder="Enter banned word" required>
            <button type="submit">Add Word</button>
        </form>
        <p><?php echo $message; ?></p>

        <h3>Current Banned Words:</h3>
        <ul>
            <?php foreach ($bannedWords as $word) { echo "<li>{$word['word']}</li>"; } ?>
        </ul>
    </div>

</body>
</html>
