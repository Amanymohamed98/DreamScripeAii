<?php
session_start(); 
if (!isset($_SESSION['user_type'])) {
    $_SESSION['user_type'] = 'parent'; 
}
$user_type = $_SESSION['user_type'];

$bannedWords = ["badword1", "badword2", "no", "test"]; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Text - Dream Scribe AI</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f8f8f8; }
        .container { width: 90%; margin: 50px auto; display: flex; justify-content: space-between; align-items: center; }
        .left-section { width: 40%; text-align: left; }
        .left-section h2 { font-size: 28px; margin-bottom: 20px; }
        .options { display: flex; flex-direction: column; gap: 20px; }
        .option img { width: 60px; height: 60px; }
        .option label, .option select { font-size: 14px; color: gray; display: block; margin-top: 5px; }
        .notebook { width: 55%; height: 400px; border: 1px solid #ddd; padding: 20px; background: #fff; }
        .notebook textarea { width: 100%; height: 100%; border: none; font-size: 18px; line-height: 1.8; resize: none; }
        .generate-btn { background-color: #003a53; color: white; padding: 10px 20px; font-size: 16px; cursor: pointer; margin-top: 10px; border-radius: 5px; }
        .generate-btn:hover { background-color: #002940; }
    </style>
</head>
<body>

<div class="container">
    <div class="left-section">
        <h2>Enter Text:</h2>
        <div class="options">
            <div class="option">
                <img src="language.jpg" alt="Choose Language">
                <label for="language">Choose Language:</label>
                <select id="language">
                    <option value="en">English</option>
                    <option value="ar">Arabic</option>
                </select>
            </div>
            <div class="option">
                <img src="narrator.jpg" alt="Choose Narrator's Voice">
                <label for="voice">Choose Narrator’s Voice:</label>
                <select id="voice">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>
            </div>
            <div class="option">
                <img src="r.jpg" alt="AI Generation">
                <p>AI generation - Wait a few minutes</p>
                <button id="generateBtn" class="generate-btn">Generate Story</button>
            </div>
        </div>
    </div>
    <div class="notebook">
        <textarea id="storyInput" placeholder="Start writing here..."></textarea>
    </div>
</div>

<div style="text-align: center; margin-top: 20px;">
    <button onclick="window.location.href='index.html'" style="background-color: #003a53; color: white; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
        Back
    </button>
    <button type="button" onclick="checkAccess()" style="background-color: #003a53; color: white; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
        Banned Words Story
    </button>
</div>

<script>
    let bannedWords = <?php echo json_encode($bannedWords); ?>;
    let userType = "<?php echo $user_type; ?>"; 
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("generateBtn").addEventListener("click", handleStorySubmission);
    });

    function checkBannedWords() {
        let textarea = document.getElementById("storyInput");
        let text = textarea.value.trim();
        let foundWords = [];

        bannedWords.forEach(word => {
            let regex = new RegExp("\\b" + word + "\\b", "gi");
            if (regex.test(text)) {
                foundWords.push(word);
                text = text.replace(regex, "****"); 
            }
        });

        textarea.value = text;

        if (foundWords.length > 0) {
            alert("⚠️ The following words were removed: " + foundWords.join(", "));
            return true;
        }
        return false;
    }

    function handleStorySubmission() {
        console.log(" Button Clicked!");

        if (checkBannedWords()) {
            return; 
        }

        let storyText = document.getElementById("storyInput").value.trim();
        if (storyText === "") {
            alert(" Please write a story before proceeding!");
            return;
        }

        let stories = JSON.parse(localStorage.getItem("stories")) || [];

        if (stories.length >= 3) {
            alert(" You have reached the limit of 3 stories! Please delete one before adding a new story.");
            return;
        }

        stories.push(storyText);
        localStorage.setItem("stories", JSON.stringify(stories)); 

        alert(" Story saved successfully!");

        setTimeout(() => {
            window.location.href = "animation_video.html";
        }, 1000);
    }

    function checkAccess() {
        let storyText = document.getElementById("storyInput").value.trim();

        if (storyText === "") {
            alert(" No story available to check.");
            return;
        }

        if (userType === "parent") {
            window.location.href = "banned_words.php";
        } else {
            alert(" You do not have permission to access this page!");
        }
    }
</script>
</body>
</html>
