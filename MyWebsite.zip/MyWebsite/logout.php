<?php
session_start();
session_destroy(); // session end
header("Location: login.php"); 
exit();
?>
