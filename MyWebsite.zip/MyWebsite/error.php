<!DOCTYPE html>
<html lang="en">
<head>
    <title>Error</title>
</head>
<body>
    <h2>Access Denied</h2>
    <p>You do not have permission to access this page.</p>
    <a href="index.html">Go Back</a>
</body>
</html>
